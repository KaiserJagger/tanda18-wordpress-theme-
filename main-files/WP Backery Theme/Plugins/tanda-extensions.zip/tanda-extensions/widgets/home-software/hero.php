<?php

/**
* Adds new shortcode "homesoftware-hero-section-shortcode" and registers it to
* the WPBakery Visual Composer plugin
*
*/


// If this file is called directly, abort

if ( ! defined( 'ABSPATH' ) ) {
    die ('Silly human what are you doing here');
}


if ( ! class_exists( 'home_software_hero_section' ) ) {

    class home_software_hero_section {


        /**
        * Main constructor
        *
        */
        public function __construct() {

            // Registers the shortcode in WordPress
            add_shortcode( 'homesoftware-hero-section-shortcode', array( 'home_software_hero_section', 'output' ) );

            // Map shortcode to Visual Composer
            if ( function_exists( 'vc_lean_map' ) ) {
                vc_lean_map( 'homesoftware-hero-section-shortcode', array( 'home_software_hero_section', 'map' ) );
            }

        }


        /**
        * Map shortcode to VC
    *
    * This is an array of all your settings which become the shortcode attributes ($atts)
        * for the output.
        *
        */
        public static function map() {
            return array(
                'name'        => esc_html__( 'Hero Section', 'tanda' ),
                'description' => esc_html__( 'Home - Hero Section', 'tanda' ),
                'base'        => 'vc_infobox',
                'category' => __('Home-10', 'tanda'),
                'icon' => plugin_dir_path( __FILE__ ) . 'assets/img/note.png',
                'params'      => array(

                    // Hero Attributes
                    array(
                        'type'       => 'attach_image',
                        'holder' => 'img',
                        'heading' => esc_html__( 'Hero Image', 'tanda' ),
                        'param_name' => 'heroimg',
                        'admin_label' => false,
                        'weight' => 0,
                        'group' => 'General',
                    ),

                    array(
                        'type' => 'textfield',
                        'holder' => 'h1',
                        'heading' => esc_html__( 'Heading', 'tanda' ),
                        'param_name' => 'heading',
                        'admin_label' => false,
                        'weight' => 0,
                        'group' => 'General',
                    ),

                    array(
                        'type' => 'textfield',
                        'holder' => 'h1',
                        'heading' => esc_html__( 'Heading Bold Text', 'tanda' ),
                        'param_name' => 'bold',
                        'admin_label' => false,
                        'weight' => 0,
                        'group' => 'General',
                    ),

                    array(
                        'type' => 'textarea',
                        'holder' => 'p',
                        'heading' => esc_html__( 'Description', 'tanda' ),
                        'param_name' => 'des',
                        'admin_label' => false,
                        'weight' => 0,
                        'group' => 'General',
                    ),

                    array(
                        'type' => 'textfield',
                        'holder' => 'h1',
                        'heading' => esc_html__( 'Button Text', 'tanda' ),
                        'param_name' => 'bttext',
                        'admin_label' => false,
                        'weight' => 0,
                        'group' => 'Button',
                    ),

                    array(
                        'type' => 'textfield',
                        'holder' => 'h1',
                        'heading' => esc_html__( 'Button Link', 'tanda' ),
                        'param_name' => 'btlink',
                        'admin_label' => false,
                        'weight' => 0,
                        'group' => 'Button',
                    ),

                    array(
                        'type' => 'textfield',
                        'holder' => 'h1',
                        'heading' => esc_html__( 'Button Icon Class', 'tanda' ),
                        'description' => sprintf( esc_html__( 'To Choose Icons Class Visit %sFont Awesome Icons%s', 'tanda' ), '<a href="https://fontawesome.com/icons?d=gallery" target="_blank">', '</a>' ),
                        'param_name' => 'bticon',
                        'admin_label' => false,
                        'weight' => 0,
                        'group' => 'Button',
                    ),

                   
                ),
            );
        }


        /**
        * Shortcode output
        *
        */
        public static function output( $atts = null ) {

            extract(
                shortcode_atts(
                    array(
                        'heroimg' => 'heroimg',
                        'title'   => '',
                        'heading' => '',
                        'bold' => '',
                        'des'   => '',
                        'bttext'   => '',
                        'btlink'   => '',
                        'bticon'   => '',
                    ),
                    $atts
                )
            );

        $img_url = wp_get_attachment_image_src( $heroimg, "full");
        

        // Fill $html var with data
        $html = '<!-- Start Banner 
============================================= -->
<div class="banner-area home2-banner-fix banner-style-eleven shape center-item text-color">
    <div class="item">
        <div class="container">
            <div class="row align-center">
                                
                <div class="col-lg-7">
                    <div class="content">
                        <h2 class="wow fadeInDown">'. $heading .' <strong>'. $bold .'</strong></h2>
                        <p class="wow fadeInLeft">
                            '. $des .'
                        </p>';
                        if (empty($bttext)) {}
            else {
                        $html.='<div class="button wow fadeInDown" data-wow-delay="700ms">
                            <a href="'. $btlink .'" class="popup-youtube video-btn"><i class="'. $bticon .'"></i>'. $bttext .'</a>
                        </div>'; }
                    $html.='</div>
                </div>
                <div class="col-lg-5 thumb">
                    <img class="wow fadeInUp" src="'. $img_url[0] .'" alt="Thumb">
                </div>

            </div>
        </div>
    </div>
</div>
<!-- End Banner -->';

        return $html;

        }

    }

}
new home_software_hero_section;