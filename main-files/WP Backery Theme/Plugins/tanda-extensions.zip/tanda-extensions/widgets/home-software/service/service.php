<?php

/**
* Adds new shortcode "home10-service-section-shortcode" and registers it to
* the WPBakery Visual Composer plugin
*
*/


// If this file is called directly, abort

if ( ! defined( 'ABSPATH' ) ) {
    die ('Silly human what are you doing here');
}


if ( ! class_exists( 'home10_service_section' ) ) {

    class home10_service_section {


        /**
        * Main constructor
        *
        */
        public function __construct() {

            // Registers the shortcode in WordPress
            add_shortcode( 'home10-service-section-shortcode', array( 'home10_service_section', 'output' ) );

            // Map shortcode to Visual Composer
            if ( function_exists( 'vc_lean_map' ) ) {
                vc_lean_map( 'home10-service-section-shortcode', array( 'home10_service_section', 'map' ) );
            }

        }


        /**
        * Map shortcode to VC
    *
    * This is an array of all your settings which become the shortcode attributes ($atts)
        * for the output.
        *
        */
        public static function map() {
            return array(
                'name'        => esc_html__( 'Home10 Service Section', 'tanda' ),
                'description' => esc_html__( 'home10 - service Section', 'tanda' ),
                'base'        => 'vc_infobox',
                'category' => __('Home-10', 'tanda'),
                'icon' => plugin_dir_path( __FILE__ ) . 'assets/img/note.png',
                'params'      => array(

                    array(
                        'type'       => 'attach_image',
                        'holder' => 'img',
                        'heading' => esc_html__( 'Hero Image', 'tanda' ),
                        'param_name' => 'heroimg',
                        'admin_label' => false,
                        'weight' => 0,
                        'group' => 'General',
                    ),

                    array(
                        'type' => 'textfield',
                        'holder' => 'h1',
                        'heading' => esc_html__( 'Grid End', 'tanda' ),
                        'param_name' => 'grid',
                        'admin_label' => false,
                        'weight' => 0,
                        'group' => 'General',
                    ),

                    array(
                        'type' => 'textfield',
                        'holder' => 'h1',
                        'heading' => esc_html__( 'Title', 'tanda' ),
                        'param_name' => 'bttext',
                        'admin_label' => false,
                        'weight' => 0,
                        'group' => 'General',
                    ),

                    array(
                        'type' => 'textfield',
                        'holder' => 'h1',
                        'heading' => esc_html__( 'Link', 'tanda' ),
                        'param_name' => 'btlink',
                        'admin_label' => false,
                        'weight' => 0,
                        'group' => 'General',
                    ),


                    array(
                        'type' => 'textarea',
                        'holder' => 'h1',
                        'heading' => esc_html__( 'Description', 'tanda' ),
                        'param_name' => 'des',
                        'admin_label' => false,
                        'weight' => 0,
                        'group' => 'General',
                    ),


                ),
            );
        }


        /**
        * Shortcode output
        *
        */
        public static function output( $atts = null ) {

            extract(
                shortcode_atts(
                    array(
                        'bttext' => '',
                        'grid' => '',
                        'btlink' => '',
                        'des' => '',
                        'heroimg' => 'heroimg',


                    ),
                    $atts
                )
            );

        $img_url1 = wp_get_attachment_image_src( $heroimg, "full");

        // Fill $html var with data
        $html.='';
        if (empty($grid)) {}
            else {
        $html.='</div><div class="col-lg-6 col-md-6 item-grid">';
    }
        $html.= '<!-- Single Item -->
                    <div class="services-style-eleven">
                        <div class="item">
                            <div class="icon">
                                <img src="'. $img_url1[0].'" alt="Icon">
                            </div>
                            <div class="info">
                                <h5><a href="'. $btlink .'">'. $bttext .'</a></h5>
                                <p>
                                    '. $des .'
                                </p>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Item -->';

                    

        return $html;

        }

    }

}
new home10_service_section;