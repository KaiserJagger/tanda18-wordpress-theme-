<?php

/**
* Adds new shortcode "home11-about-section-shortcode" and registers it to
* the WPBakery Visual Composer plugin
*
*/


// If this file is called directly, abort

if ( ! defined( 'ABSPATH' ) ) {
    die ('Silly human what are you doing here');
}


if ( ! class_exists( 'home11_about_section' ) ) {

    class home11_about_section {


        /**
        * Main constructor
        *
        */
        public function __construct() {

            // Registers the shortcode in WordPress
            add_shortcode( 'home11-about-section-shortcode', array( 'home11_about_section', 'output' ) );

            // Map shortcode to Visual Composer
            if ( function_exists( 'vc_lean_map' ) ) {
                vc_lean_map( 'home11-about-section-shortcode', array( 'home11_about_section', 'map' ) );
            }

        }


        /**
        * Map shortcode to VC
    *
    * This is an array of all your settings which become the shortcode attributes ($atts)
        * for the output.
        *
        */
        public static function map() {
            return array(
                'name'        => esc_html__( 'Home11 About Section', 'tanda' ),
                'description' => esc_html__( 'Home11 - About Section', 'tanda' ),
                'base'        => 'vc_infobox',
                'category' => __('Home-11', 'tanda'),
                'icon' => plugin_dir_path( __FILE__ ) . 'assets/img/note.png',
                'params'      => array(

                    // Hero Attributes

                    array(
                        'type'       => 'attach_image',
                        'holder' => 'img',
                        'heading' => esc_html__( 'BG Image', 'tanda' ),
                        'param_name' => 'bgimg',
                        // 'value' => __( 'Default value', 'tanda' ),
                        'admin_label' => false,
                        'weight' => 0,
                        'group' => 'Left',
                    ),

                    array(
                        'type'       => 'attach_image',
                        'holder' => 'img',
                        'heading' => esc_html__( 'Image One', 'tanda' ),
                        'param_name' => 'heroimg',
                        // 'value' => __( 'Default value', 'tanda' ),
                        'admin_label' => false,
                        'weight' => 0,
                        'group' => 'Left',
                    ),

                    array(
                        'type'       => 'attach_image',
                        'holder' => 'img',
                        'heading' => esc_html__( 'Image Two', 'tanda' ),
                        'param_name' => 'heroimg1',
                        // 'value' => __( 'Default value', 'tanda' ),
                        'admin_label' => false,
                        'weight' => 0,
                        'group' => 'Left',
                    ),

                    array(
                        'type'       => 'attach_image',
                        'holder' => 'img',
                        'heading' => esc_html__( 'Image Three', 'tanda' ),
                        'param_name' => 'heroimg2',
                        // 'value' => __( 'Default value', 'tanda' ),
                        'admin_label' => false,
                        'weight' => 0,
                        'group' => 'Left',
                    ),

                    array(
                        'type' => 'textfield',
                        'holder' => 'h1',
                        'heading' => esc_html__( 'Title', 'tanda' ),
                        'param_name' => 'title',
                        'admin_label' => false,
                        'weight' => 0,
                        'group' => 'General',
                    ),

                    array(
                        'type' => 'textfield',
                        'holder' => 'h1',
                        'heading' => esc_html__( 'Heading', 'tanda' ),
                        'param_name' => 'heading',
                        'admin_label' => false,
                        'weight' => 0,
                        'group' => 'General',
                    ),

                    array(
                        'type' => 'textarea',
                        'holder' => 'p',
                        'heading' => esc_html__( 'Description', 'tanda' ),
                        'param_name' => 'des',
                        'admin_label' => false,
                        'weight' => 0,
                        'group' => 'General',
                    ),

                    array(
                        'type'       => 'attach_image',
                        'holder' => 'img',
                        'heading' => esc_html__( 'Icon Image', 'tanda' ),
                        'param_name' => 'iconimg',
                        // 'value' => __( 'Default value', 'tanda' ),
                        'admin_label' => false,
                        'weight' => 0,
                        'group' => 'Icon',
                    ),

                    array(
                        'type' => 'textfield',
                        'holder' => 'h1',
                        'heading' => esc_html__( 'Title', 'tanda' ),
                        'param_name' => 'icon_title',
                        'admin_label' => false,
                        'weight' => 0,
                        'group' => 'Icon',
                    ),

                    array(
                        'type' => 'textarea',
                        'holder' => 'p',
                        'heading' => esc_html__( 'Description', 'tanda' ),
                        'param_name' => 'icon_des',
                        'admin_label' => false,
                        'weight' => 0,
                        'group' => 'Icon',
                    ),

                    array(
                        'type' => 'textfield',
                        'holder' => 'h1',
                        'heading' => esc_html__( 'Title', 'tanda' ),
                        'param_name' => 'bt_text',
                        'admin_label' => false,
                        'weight' => 0,
                        'group' => 'Button',
                    ),

                    array(
                        'type' => 'textfield',
                        'holder' => 'h1',
                        'heading' => esc_html__( 'Link', 'tanda' ),
                        'param_name' => 'bt_link',
                        'admin_label' => false,
                        'weight' => 0,
                        'group' => 'Button',
                    ),
                   
                ),
            );
        }


        /**
        * Shortcode output
        *
        */
        public static function output( $atts = null ) {

            extract(
                shortcode_atts(
                    array(
                        'bgimg' => 'bgimg',
                        'heroimg' => 'heroimg',
                        'heroimg1' => 'heroimg1',
                        'heroimg2' => 'heroimg2',
                        'iconimg' => 'iconimg',
                        'title'   => '',
                        'heading' => '',
                        'des'   => '',
                        'icon'   => '',
                        'icon_title'   => '',
                        'icon_des'   => '',
                        'bt_text'   => '',
                        'bt_link'   => '',


                    ),
                    $atts
                )
            );

        $img_url = wp_get_attachment_image_src( $heroimg, "full");
        $img_url1 = wp_get_attachment_image_src( $heroimg1, "full");
        $img_url2 = wp_get_attachment_image_src( $heroimg2, "full");
        $img_url3 = wp_get_attachment_image_src( $bgimg, "full");
        $img_url4 = wp_get_attachment_image_src( $iconimg, "full");
        

        // Fill $html var with data
        $html = '<!-- Start About 
============================================= -->
<div class="about-style-ten-area bg-cover overflow-hidden bg-gray shadow dark default-padding" style="background-image: url('. $img_url3[0] .');">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 about-style-ten">
                <div class="thumb">
                    <img src="'. $img_url[0] .'" alt="Thumb">
                    <img src="'. $img_url1[0] .'" alt="Thumb">
                    <img src="'. $img_url2[0] .'" alt="Thumb">
                </div>
            </div>
            <div class="col-lg-6 about-style-ten">
                <div class="info">
                    <h5>'. $title .'</h5>
                    <h2>'. $heading .'</h2>
                    <p>
                        '. $des .'
                    </p>
                    <ul>
                        <li>
                            <div class="icon">
                                <img src="'. $img_url4[0] .'" alt="icon">
                            </div>
                            <div class="info">
                                <h4>'. $icon_title .'</h4>
                                <p>
                                    '. $icon_des .'
                                </p>
                            </div>
                        </li>
                    </ul>
                    <a class="btn circle btn-theme effect btn-md" href="'. $bt_link .'">'. $bt_text.'</a>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End About Area -->';

        return $html;

        }

    }

}
new home11_about_section;